package com.interviewcoach.integration.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.interviewcoach.config.OpenAiProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class OpenAiChatClient {

    private final RestTemplate restTemplate;
    private final OpenAiProperties openAiProperties;
    private final ObjectMapper objectMapper;

    public String getStructuredJsonResponse(String developerPrompt, String userPrompt) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(openAiProperties.getApiKey());

        Map<String, Object> requestBody = Map.of(
                "model", openAiProperties.getModel(),
                "messages", List.of(
                        Map.of(
                                "role", "developer",
                                "content", developerPrompt
                        ),
                        Map.of(
                                "role", "user",
                                "content", userPrompt
                        )
                ),
                "response_format", Map.of(
                        "type", "json_schema",
                        "json_schema", Map.of(
                                "name", "skill_gap_analysis",
                                "schema", Map.of(
                                        "type", "object",
                                        "additionalProperties", false,
                                        "properties", Map.of(
                                                "fitScore", Map.of(
                                                        "type", "integer",
                                                        "minimum", 0,
                                                        "maximum", 100
                                                ),
                                                "matchedSkills", Map.of(
                                                        "type", "array",
                                                        "items", Map.of("type", "string")
                                                ),
                                                "missingSkills", Map.of(
                                                        "type", "array",
                                                        "items", Map.of("type", "string")
                                                ),
                                                "recommendedTopics", Map.of(
                                                        "type", "array",
                                                        "items", Map.of("type", "string")
                                                ),
                                                "summary", Map.of(
                                                        "type", "string"
                                                )
                                        ),
                                        "required", List.of(
                                                "fitScore",
                                                "matchedSkills",
                                                "missingSkills",
                                                "recommendedTopics",
                                                "summary"
                                        )
                                )
                        )
                ),
                "temperature", 0.3
        );

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.exchange(
                openAiProperties.getBaseUrl(),
                HttpMethod.POST,
                entity,
                String.class
        );

        return extractContent(response.getBody());
    }

    private String extractContent(String responseBody) {
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode contentNode = root.path("choices").get(0).path("message").path("content");

            if (contentNode.isTextual()) {
                return contentNode.asText();
            }

            if (contentNode.isArray() && contentNode.size() > 0) {
                JsonNode first = contentNode.get(0);
                if (first.has("text")) {
                    return first.get("text").asText();
                }
            }

            throw new IllegalStateException("Unable to extract AI response content");
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to parse OpenAI response: " + ex.getMessage(), ex);
        }
    }
}